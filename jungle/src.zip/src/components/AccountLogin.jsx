// Useless file, all functionality is in Login.jsx
import React, { useState } from "react";

export default function AccountLogin() {
  return (
    <div>
      <h1>This is the Login Page</h1>
    </div>
  );
}
