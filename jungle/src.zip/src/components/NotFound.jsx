export default function NotFound() {
    return (
        <div>
            <h1>Error 404: Page not Found</h1>
            <p>Sorry, this page is not available :(</p>
        </div>
    );
}